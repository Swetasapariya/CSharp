﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter you number:");
            int num = Convert.ToInt32(Console.ReadLine());
            int i = 1, k = 1, old = 0, New = 0, temp = 0;
            do
            {
                int j = 1;
                do
                {
                    if (k <= 3)
                    {
                        Console.Write(k + "\t");
                        New = k;
                        old = k - 1;
                    }
                    else
                    {
                        temp = old * New;
                        if (temp > num)
                        {
                            break;
                        }
                        Console.Write(temp + "\t");
                        old = New;
                        New = temp;
                    }
                    k++;
                    j++;
                } while (j <= i);
                if (temp > num)
                {
                    break;
                }
                Console.WriteLine();
                i++;
            } while (i < num);

            Console.WriteLine();
            //Console.Read();

            //while

            int a = 1, c = 1, t = 0;
            while (a < num)
            {
                int b = 1;
                while (b <= a)
                {
                    if (c <= 3)
                    {
                        Console.Write(c + "\t");
                        New = c;
                        old = c - 1;
                    }
                    else
                    {
                        t = old * New;
                        if (t > num)
                        {
                            break;
                        }
                        Console.Write(t + "\t");
                        old = New;
                        New = t;
                    }
                    c++;
                    b++;
                } //while (j <= i);
                if (t > num)
                {
                    break;
                }
                Console.WriteLine();
                a++;
            } //while (i < num);

            Console.WriteLine();

            //for loop

            int p, q, r = 1, te = 0;
            for (p = 1; p < num; p++)
            {

                for (q = 1; q <= p; q++)
                {
                    if (r <= 3)
                    {
                        //r++;
                        Console.Write(r + "\t");
                        New = r;
                        old = r - 1;
                        r++;
                    }
                    else
                    {
                        te = old * New;
                        if (te > num)
                        {
                            break;
                        }
                        Console.Write(te + "\t");
                        old = New;
                        New = te;
                    }
                }
                if (te > num)
                {
                    break;
                }
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Read();
        

        }
    }
}
